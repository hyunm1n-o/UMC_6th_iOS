//
//  UserInfo.swift
//  UMC_study_2st_mission
//
//  Created by 오현민 on 5/9/24.
//

import Foundation

struct UserInfo {
    let email: String
    let name: String
    let nickname: String
    let password: String
}
