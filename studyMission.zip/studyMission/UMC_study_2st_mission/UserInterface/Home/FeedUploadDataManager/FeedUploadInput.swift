//
//  FeedUploadInput.swift
//  UMC_study_2st_mission
//
//  Created by 오현민 on 7/1/24.
//

struct FeedUploadInput : Encodable {
    var content : String?
    var postImageUrl : [String]?
}
