//
//  FeedUploadModel.swift
//  UMC_study_2st_mission
//
//  Created by 오현민 on 7/1/24.
//

struct FeedUploadModel : Decodable {
    var isSuccess : Bool
    var code : Int
    var message : String
    var result : FeedUploadResult?
}

struct FeedUploadResult : Decodable {
    var postIdx : Int?
}
