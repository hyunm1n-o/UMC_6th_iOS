//
//  UserFeedDataManager.swift
//  UMC_study_2st_mission
//
//  Created by 오현민 on 7/1/24.
//

import Foundation
import Alamofire

class UserFeedDataManager {
    func getUserFeed(_ userID : Int = 2, _ viewController : ProfileViewController) {
        AF.request("https://edu-api-ios-test.softsquarde.com/users/\(userID)",
                   method: .get,
                   parameters: nil).validate().responseDecodable(of: UserFeedModel.self) { response in
            
            switch response.result {
            case .success(let result):
                print(result)
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}
